/**
 * Allows the user to input a credit card number and checks the validity using Luhn's algorithm
 * Created by John Callaghan in 2017 for cs50
 */
 
#include <cs50.h>
#include <stdio.h>
#include <string.h>

string get_cardnumber(int argc, string argv[]);
bool check_number(string cardnumber);
string get_brand(string cardnumber);
string err_number(void);

int main(int argc, string argv[])
{
    string cardnumber = get_cardnumber(argc, argv);
    while (check_number(cardnumber) == false)
    {
        printf("Retry: ");
        cardnumber = get_string();
    }
    
    int checksum = 0;
    int checksum2 = 0;
    int n = 0;
        
    // loop to add numbers up
    for (int i = strlen(cardnumber)-1 ; i > 0; i--)
    {
        // i suspect that I can use this loop to calculate the multiplications
        // but i need to figure out even and odd?
        
        // decide whether it's an even or an odd number iteration in the loop
        printf("%i (%i)", i, cardnumber[i]-48);
        if (n % 2 != 0)
        {
            // Multiply every other digit by 2, starting with the number’s second-to-last digit, 
            // and then add those products' digits together.
            checksum += (((int) cardnumber[i]-48) *2);
            printf(" t %i = %i\n", (cardnumber[i]-48)*2, checksum);
            
            // PROBLEM IS THAT FOR NUMBERS MORE THAN 10 ITS NOT COUNTING EACH DIGIT INDIVIDUALLY
        }
        else
        {
            // multiply the other digits in the same way
            checksum2 += ((int) cardnumber[i]-48);
            printf(" a %i = %i\n", cardnumber[i]-48, checksum2);
        }
        n++;
    }
                
    // check which brand the card is and is it the correct length
    string brandname = get_brand(cardnumber);
    
    // then we can check the Luhn's multiplications, returning invalid if there's an issue
    // add both of the sums together
    // If the total’s last digit is 0 (or, put more formally, if the total modulo 10 is congruent to 0)
    printf("%i + %i = %i\n", checksum, checksum2, checksum + checksum2);
    if (checksum % 10 != 0)
    {
        brandname = "INVALID";
    }

    // All the checks were successful, success
    printf("%s\n", brandname);
    return 0;
}

// function to check for command line arguments or get string input if none exist
string get_cardnumber(int argc, string argv[])
{
    // check for command line arguments
    if (argc > 1)
    {
        // take argument 2 as the credit card number input
        return argv[1];
    }
    
    else
    {
        // fetch an input from the user
        printf("Number: ");
        return get_string();
    }
}

// check the string is numbers only, not null and not ridiculously short (<13)
bool check_number(string cardnumber)
{
    if (cardnumber == NULL)
    {
        return false;
    }
    else
    {
        for (int i = 0, n = strlen(cardnumber); i < n; i++)
        {
            // check for anything other than numbers
            if (cardnumber[i] < 48 || cardnumber[i] > 57)
            {
                return false;
            }
        }
    }
    return true;
}

// function to ake the first two digits of the string and identify card brand
string get_brand(string cardnumber)
{
    // get the brand number from the string
    int brand =  (int) ((cardnumber[0]-48)*10)+(cardnumber[1]-48);
    
    // compare the length of cardnumber against what we expect for each brand
    switch (brand)
    {
        // card is American Express - 15 digits
        case 34:
        case 37:
            return (strlen(cardnumber) == 15) ? "AMEX" : "INVALID";
            break;
        // card is Visa - 13 or 16 digits
        case 40 ... 49:
            if (strlen(cardnumber) == 13 || strlen(cardnumber) == 16)
            {
                return "VISA";
            }
            else
            {
                return "INVALID";
            }
            
            break;
        // card is Mastercard - 16 digits
        case 51 ... 55:
            return (strlen(cardnumber) == 16) ? "MASTERCARD" : "INVALID";
            break;
        default:
            return "INVALID";
            break;
    }
}

// function to get input again
string err_number(void)
{
    printf("Retry: ");
    return get_string();
}